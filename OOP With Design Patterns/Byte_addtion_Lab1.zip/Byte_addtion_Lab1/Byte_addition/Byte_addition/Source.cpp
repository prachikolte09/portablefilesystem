/*
FileName: Source.cpp
Author: : Provided by Professor
Date: 26th September 2016
Compiler Used: Microsoft (R) C/C++ Optimizing Compiler
Functioning: Source file which contains main. It accepts the input and creates the output file
             File also contains the functionality to display data in particular pattern.
*/
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
#include "MyByte.h"
int main()
{
	cout << "Program Starting ...\n\n";
	cout << "Opening Files ...\n\n";
	ifstream in;
	in.open("input.txt");
	ofstream out;
	out.open("output.txt");
	cout << "Files Opened Successfully ...\n\n";
	MyByte b1, b2, sum;
	int dec_sum;
	while (in >> b1 && in >> b2)
	{
		// Number crunching part
		sum = b1 + b2;
		dec_sum = b1.toDecimal() + b2.toDecimal();
		// Output to screen
		cout << " " << b1 << "\t" << b1.getcomplementtype()
			<< "\t" << std::right << std::setw(8) << b1.toDecimal() << endl;
		cout << "+" << b2 << "\t" << b2.getcomplementtype()
			<< "\t" << std::right << std::setw(8) << b2.toDecimal() << endl;
		cout << "-----------\t\t\t\t"
			<< std::right << std::setw(8) << "----" << endl;
		cout << " " << sum << "\t" << sum.getcomplementtype()
		     << "\t" << std::right << std::setw(8) << dec_sum << endl << endl;
		// Output to file
		out << " " << b1 << "\t" << b1.getcomplementtype()
		    << "\t" << std::right << std::setw(8) << b1.toDecimal() << endl;
		out << "+" << b2 << "\t" << b2.getcomplementtype()
		<< "\t" << std::right << std::setw(8) << b2.toDecimal() << endl;
		out << "-----------\t\t\t\t\t\t"
		<< std::right << std::setw(8) << "----" << endl;
		out << " " << sum << "\t" << sum.getcomplementtype()
		<< "\t" << std::right << std::setw(8) << dec_sum << endl << endl;
	}
	return 0;
}