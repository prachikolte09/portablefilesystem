/*
FileName: MyByte.h
Author: Prachi Kolte
Date: 26th September 2016
Compiler Used: Microsoft (R) C/C++ Optimizing Compiler
Functioning: File is header file for the Byte addition which provides class definitions and its member functions.
             and the macro definitions for the resulting strings.
             
*/
#pragma once

#include <iostream>
#include <string>
#include <bitset>

using namespace std;

#define MIN_SUM -128
#define UNDERFLOW_MSG "underflow"
#define OVERFLOW_MSG "overflow"
#define ERROR_MSG "*****ERROR******"
#define MAX_SUM 127
#define COMPLEMENTTYPE "2's complement"

typedef unsigned char Byte;

class MyByte {
public:
	MyByte();
	MyByte(string); //constructor to initialize an object with byte string (i.e. _byte field)
	MyByte(int); //constructor to initialize an object with signedvalue (i.e. _signedvalue field)
	int toDecimal();
	string getcomplementtype();
	MyByte operator+(MyByte& b);
	friend ostream& operator<<(ostream& os, const MyByte& myByte);
	friend istream& operator >> (istream& is, MyByte& myByte);
	

private:
	string _byte;
	string _complementtype;
	int _signedvalue;

	/* static functions */
	static MyByte createUnderflowMyByte(int signedvalue);
	static MyByte createOverflowMyByte(int signedvalue);
	static int getSignedValue(string byteString);
	static string getByteString(int signedvalue);
};
